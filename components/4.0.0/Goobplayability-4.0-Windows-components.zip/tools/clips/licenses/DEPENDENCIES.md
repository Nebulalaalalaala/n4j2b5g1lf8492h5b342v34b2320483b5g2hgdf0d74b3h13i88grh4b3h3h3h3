# Bundled dependencies

GoobCapture uses Vortice.Direct3D11 / Vortice.DXGI 3.6.2 (MIT; Amer Koleci and contributors),
SharpGen.Runtime 2.2.0-beta (MIT; Alexandre Mutel, Jeremy Koritzinsky, Amer Koleci and contributors),
the Microsoft Windows SDK .NET projection 10.0.19041.31, and the self-contained .NET runtime 8.0.33.

- Vortice source/license: https://github.com/amerkoleci/Vortice.Windows
- SharpGen source/license: https://github.com/SharpGenTools/SharpGenTools
- Windows SDK license: https://aka.ms/WinSDKLicenseURL
- .NET source: https://github.com/dotnet/runtime

The included FFmpeg is the existing local 7.0.2 full Gyan build. Its GPLv3 license and
build/source information are included. Exact upstream FFmpeg source commit, as recorded
by that build: https://github.com/FFmpeg/FFmpeg/commit/e3a61e9103.
FFmpeg is invoked as a separate encoding process; the application does not load its DLLs.
Keep these notices and the corresponding source/build information with redistribution.

The recorder's source and locked NuGet dependency graph are in ../recorder-source.
The notification WAVs were synthesized for this implementation; no downloaded sound pack is used.
