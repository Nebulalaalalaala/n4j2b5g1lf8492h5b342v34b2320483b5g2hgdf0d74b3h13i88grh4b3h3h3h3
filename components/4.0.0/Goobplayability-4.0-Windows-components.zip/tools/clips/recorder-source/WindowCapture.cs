using System.Diagnostics;
using System.Runtime.InteropServices;
using Windows.Graphics.Capture;
using Windows.Graphics.DirectX;
using Windows.Graphics.DirectX.Direct3D11;
using Vortice.Direct3D;
using Vortice.Direct3D11;
using Vortice.DXGI;
using WinRT;

namespace GoobCapture;

// Capture only the game's client area. Fullscreen display capture is gated by
// foreground process BEFORE reading pixels; switching away never records other apps.
sealed class WindowCapture : IDisposable
{
    ID3D11Device device = null!;
    ID3D11DeviceContext context = null!;
    IDirect3DDevice winrt = null!;
    GraphicsCaptureItem item = null!;
    Direct3D11CaptureFramePool pool = null!;
    GraphicsCaptureSession session = null!;
    readonly object gate = new();
    ID3D11Texture2D? staging;
    byte[]? latest;
    byte[][]? buffers;
    readonly Queue<(int Slot,double Time)> queued = new();
    int nextSlot;
    public int Width { get; private set; }
    public int Height { get; private set; }
    public long LastFrameMs { get; private set; }
    public long ReceivedFrames { get; private set; }
    public long AcquisitionAttempts { get; private set; }
    public bool Closed { get; private set; }
    public string? Error { get; private set; }
    nint hwnd;
    nint monitor;
    readonly int ownerPid;
    readonly string mode;
    bool display;
    bool switching;
    CancellationTokenSource? displayCancel;
    Task? displayTask;
    bool disposed;
    readonly int fps;
    double nextRead;
    double sourceTime;
    volatile bool deviceResetRequested;
    int deviceRecoveryAttempts;
    long deviceResets;
    public long DeviceResets => Interlocked.Read(ref deviceResets);
    long activeSince = Environment.TickCount64;
    bool wasCapturable;
    long recoveries;
    public long Recoveries => Interlocked.Read(ref recoveries);
    public string LastRecovery { get; private set; } = "";
    public Exception? FailureException { get; private set; }
    public Action<string>? Diagnostics { get; set; }
    public bool TerminalFailure => Error != null && Capturable && Environment.TickCount64-activeSince>12000 && Environment.TickCount64-LastFrameMs>12000;
#if CAPTURE_TESTS
    internal static Action<IDXGIOutputDuplication>? TestAcquiredFrame;
#endif
    void Fault(string operation, Exception exception)
    {
        FailureException = exception;
        LastRecovery = operation + ": " + exception.Message;
        Interlocked.Increment(ref recoveries);
        Diagnostics?.Invoke(operation + "\n" + exception);
    }

    public WindowCapture(int pid, int frameRate,string captureMode)
    {
        ownerPid = pid;
        mode = captureMode;
        fps = frameRate;
        if (!GraphicsCaptureSession.IsSupported()) throw new Exception("Windows game capture is unavailable. Windows 10 version 2004 or newer is required.");
        var process = Process.GetProcessById(pid);
        process.Refresh();
        hwnd = process.MainWindowHandle;
        if (hwnd == 0) throw new Exception("The game window is not ready. Open GooberDash, then try again.");
        CreateDevice();
        AttachSource(WantsDisplay());
    }

    void CreateDevice()
    {
        D3D11.D3D11CreateDevice(null, DriverType.Hardware, DeviceCreationFlags.BgraSupport,
            new[] { FeatureLevel.Level_11_1, FeatureLevel.Level_11_0 }, out device!, out context!).CheckError();
        using (var multithread = context.QueryInterfaceOrNull<ID3D11Multithread>())
            multithread?.SetMultithreadProtected(true);
        using var dxgi = device.QueryInterface<IDXGIDevice>();
        Marshal.ThrowExceptionForHR(CreateDirect3D11DeviceFromDXGIDevice(dxgi.NativePointer, out var ptr));
        winrt = WinRT.MarshalInterface<IDirect3DDevice>.FromAbi(ptr);
        Marshal.Release(ptr);
    }

    bool WantsDisplay() => mode == "display" || (mode != "window" && Fullscreen());
    bool Fullscreen()
    {
        if (!IsWindow(hwnd)) return false;
        var monitorHandle = MonitorFromWindow(hwnd,2);
        var info = new MONITORINFO { Size = Marshal.SizeOf<MONITORINFO>() };
        if (monitorHandle==0 || !GetMonitorInfo(monitorHandle,ref info)) return false;
        var m = info.Monitor;
        if (!GetClientRect(hwnd,out var c)) return false;
        var origin = new POINT();
        if (!ClientToScreen(hwnd,ref origin)) return false;
        return Math.Abs(origin.X-m.Left)<=2 && Math.Abs(origin.Y-m.Top)<=2 && c.Right>=m.Right-m.Left-2 && c.Bottom>=m.Bottom-m.Top-2;
    }
    void AttachSource(bool useDisplay)
    {
        Error = null;
        activeSince = Environment.TickCount64;
        display = useDisplay;
        monitor = MonitorFromWindow(hwnd,2);
        if (display)
        {
            displayCancel = new CancellationTokenSource();
            var token = displayCancel.Token;
            var selectedMonitor = monitor;
            displayTask = Task.Run(() => DisplayLoop(selectedMonitor,token));
            return;
        }
        var interop = GraphicsCaptureItem.As<IGraphicsCaptureItemInterop>();
        var iid = new Guid("79C3F95B-31F7-4EC2-A464-632EF5D30760");
        var rawItem = display ? interop.CreateForMonitor(monitor,iid) : interop.CreateForWindow(hwnd,iid);
        item = WinRT.MarshalInterface<GraphicsCaptureItem>.FromAbi(rawItem);
        Marshal.Release(rawItem);
        item.Closed += (source, _) => { if (!display && source == item) Closed = true; };
        pool = Direct3D11CaptureFramePool.CreateFreeThreaded(winrt, DirectXPixelFormat.B8G8R8A8UIntNormalized, 2, item.Size);
        pool.FrameArrived += Arrived;
        session = pool.CreateCaptureSession(item);
        session.IsCursorCaptureEnabled = false;
        // Keep Windows' capture border. Do not suppress the user's OS indicator.
        session.StartCapture();
    }

    public void RefreshSource()
    {
        nint current;
        try { current = Process.GetProcessById(ownerPid).MainWindowHandle; } catch { return; }
        bool changed = current != 0 && current != hwnd;
        if (changed) hwnd = current;
        bool active = Capturable;
        if (active != wasCapturable)
        {
            wasCapturable = active;
            activeSince = Environment.TickCount64;
            Error = null; // A stale error must not kill capture on focus return.
        }
        bool resetDevice = deviceResetRequested;
        deviceResetRequested = false;
        bool wanted = WantsDisplay();
        if (!resetDevice && !changed && wanted == display && (!display || MonitorFromWindow(hwnd,2) == monitor)) return;
        lock (gate) { switching = true; if (pool != null) pool.FrameArrived -= Arrived; }
        displayCancel?.Cancel(); displayTask?.Wait(); displayCancel?.Dispose();
        displayCancel = null; displayTask = null;
        session?.Dispose(); pool?.Dispose(); session = null!; pool = null!;
        lock (gate)
        {
            queued.Clear(); nextRead = 0; Closed = false;
            if (resetDevice)
            {
                Interlocked.Increment(ref deviceRecoveryAttempts);
                Interlocked.Increment(ref deviceResets);
                staging?.Dispose(); staging = null;
                if (winrt is IDisposable closeDevice) closeDevice.Dispose();
                context.Dispose(); device.Dispose();
                CreateDevice();
                Diagnostics?.Invoke("Recreated capture device; source remains " + (wanted ? "fullscreen DXGI" : "game window"));
            }
            AttachSource(wanted);
            switching = false;
        }
    }

    void Arrived(Direct3D11CaptureFramePool sender, object args)
    {
        lock (gate)
        {
            if (disposed || switching || sender != pool) return;
            try
            {
                Windows.Graphics.SizeInt32? resize = null;
                using (var frame = sender.TryGetNextFrame())
                {
                if (frame == null || frame.ContentSize.Width < 2 || frame.ContentSize.Height < 2) return;
                if (!Capturable) return;
                double now = Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;
                if (now < nextRead) return;
                nextRead = now - nextRead > .5 ? now + 1.0 / fps : nextRead + 1.0 / fps;
                // The frame owns this pooled surface. Close the FRAME, not
                // the reusable surface owned by the Windows capture pool.
                var surface = frame.Surface;
                using var texture = new ID3D11Texture2D(TexturePointer(surface));
                var desc = texture.Description;
                ReadTexture(texture,Math.Min(frame.ContentSize.Width,(int)desc.Width),Math.Min(frame.ContentSize.Height,(int)desc.Height),frame.SystemRelativeTime.TotalSeconds);
                if (frame.ContentSize.Width != desc.Width || frame.ContentSize.Height != desc.Height)
                    resize = frame.ContentSize;
                }
                // Release frame, surface and texture before recreating the pool.
                if (resize.HasValue) sender.Recreate(winrt, DirectXPixelFormat.B8G8R8A8UIntNormalized, 2, resize.Value);
            }
            catch (Exception e) { Fault("Windows frame readback", e); if (Environment.TickCount64-LastFrameMs>2000 && Volatile.Read(ref deviceRecoveryAttempts)<2) deviceResetRequested=true; Error = "Windows game capture is recovering."; }
        }
    }

    void ReadTexture(ID3D11Texture2D texture,int width,int height,double timestamp)
    {
        if (!Capturable) return;
        var desc = texture.Description;
        if (staging == null || staging.Description.Width != desc.Width || staging.Description.Height != desc.Height || staging.Description.Format != desc.Format || staging.Description.SampleDescription.Count != desc.SampleDescription.Count || staging.Description.MipLevels != desc.MipLevels || staging.Description.ArraySize != desc.ArraySize)
        {
            staging?.Dispose();
            desc.BindFlags = BindFlags.None; desc.CPUAccessFlags = CpuAccessFlags.Read;
            desc.Usage = ResourceUsage.Staging; desc.MiscFlags = ResourceOptionFlags.None;
            staging = device.CreateTexture2D(desc);
        }
        context.CopyResource(staging,texture);
        var mapped = context.Map(staging,0,MapMode.Read,Vortice.Direct3D11.MapFlags.None);
        try
        {
            var crop = ClientCrop(width,height);
            if (Width == 0) { Width = crop.w & ~1; Height = crop.h & ~1; }
            buffers ??= Enumerable.Range(0,4).Select(_ => new byte[Width * Height * 4]).ToArray();
            int slot = nextSlot++ % 4;
            latest = buffers[slot];
            if (crop.w != Width || crop.h != Height) Array.Clear(latest);
            CopyFit(mapped.DataPointer,(int)mapped.RowPitch,crop,latest,Width,Height);
            LastFrameMs = Environment.TickCount64; ReceivedFrames++; sourceTime = timestamp;
            Interlocked.Exchange(ref deviceRecoveryAttempts,0);
            while (queued.Count >= 3) queued.Dequeue();
            queued.Enqueue((slot,sourceTime)); Error = null;
        }
        finally { context.Unmap(staging,0); }
    }

    IDXGIOutputDuplication Duplicate(nint selectedMonitor)
    {
        using var dxgi = device.QueryInterface<IDXGIDevice>();
        using var adapter = dxgi.GetAdapter();
        for (uint index = 0; adapter.EnumOutputs(index,out var output).Success; index++)
        {
            using (output)
            {
                if (output.Description.Monitor != selectedMonitor) continue;
                using var capable = output.QueryInterface<IDXGIOutput1>();
                return capable.DuplicateOutput(device);
            }
        }
        throw new Exception("This display is on another graphics adapter. Move the game to the primary display or choose Game window capture.");
    }

    void DisplayLoop(nint selectedMonitor,CancellationToken token)
    {
        var failed = Stopwatch.StartNew();
        while (!token.IsCancellationRequested)
        {
            if (!Capturable) { Error = null; failed.Restart(); Thread.Sleep(40); continue; }
            string operation = "DuplicateOutput";
            try
            {
                using var duplication = Duplicate(selectedMonitor);
                var cadence = new FrameCadence(fps);
                bool ownsFrame = false;
                try
                {
                    while (!token.IsCancellationRequested)
                    {
                        if (!Capturable) { Error = null; failed.Restart(); token.WaitHandle.WaitOne(25); continue; }
                        double now = Stopwatch.GetTimestamp()/(double)Stopwatch.Frequency;
                        double wait = cadence.WaitSeconds(now);
                        if (wait > 0)
                        {
                            if (token.WaitHandle.WaitOne(Math.Max(1,(int)Math.Ceiling(wait*1000)))) break;
                            continue;
                        }
                        // Keep ownership during the sampling interval. While no
                        // client owns it, DXGI copies desktop updates on EVERY
                        // game present, including the hundreds we won't encode.
                        // Microsoft recommends Release immediately before Acquire.
                        if (ownsFrame)
                        {
                            operation = "ReleaseFrame";
                            ownsFrame = false; // Cleanup must not release twice if this call fails.
                            duplication.ReleaseFrame().CheckError();
                        }
                        operation = "AcquireNextFrame";
                        AcquisitionAttempts++;
                        var result = duplication.AcquireNextFrame(40,out var info,out var resource);
                        if (result.Code == unchecked((int)0x887A0027)) continue;
                        result.CheckError();
                        ownsFrame = true;
                        using (resource)
                        using (var texture = resource.QueryInterface<ID3D11Texture2D>())
                        {
#if CAPTURE_TESTS
                            // Test build only: provoke a REAL DXGI ownership error.
                            TestAcquiredFrame?.Invoke(duplication);
#endif
                            operation = "ReadTexture";
                            lock (gate)
                            {
                                if (disposed || switching || !Capturable) continue;
                                now = Stopwatch.GetTimestamp()/(double)Stopwatch.Frequency;
                                cadence.Accept(now);
                                double stamp = info.LastPresentTime>0 ? info.LastPresentTime/(double)Stopwatch.Frequency : now;
                                ReadTexture(texture,(int)texture.Description.Width,(int)texture.Description.Height,stamp);
                                failed.Restart();
                            }
                        }
                    }
                }
                finally
                {
                    if (ownsFrame) { try { duplication.ReleaseFrame().CheckError(); } catch { } }
                }
            }
            catch (Exception e)
            {
                Fault(operation, e);
                if (failed.Elapsed.TotalSeconds>2 && Capturable && Volatile.Read(ref deviceRecoveryAttempts)<2)
                    deviceResetRequested = true; // Recreate on main thread; never wait on this worker itself.
                if (failed.Elapsed.TotalSeconds>10 && Capturable)
                    Error = "Fullscreen capture could not recover. Restore the game window or restart the replay buffer.";
                token.WaitHandle.WaitOne(Math.Min(1000,100+(int)(failed.Elapsed.TotalSeconds*100)));
            }
        }
    }

    static unsafe nint TexturePointer(IDirect3DSurface surface)
    {
        // Explicit COM ownership matters: an RCW retained until a future GC can
        // hold capture-pool surfaces and stall capture after buffers run out.
        nint managed = WinRT.MarshalInterface<IDirect3DSurface>.FromManaged(surface);
        nint access = 0;
        try
        {
            var accessId = new Guid("A9B3D012-3DF2-4EE3-B8D1-8695F457D3C1");
            Marshal.ThrowExceptionForHR(Marshal.QueryInterface(managed,ref accessId,out access));
            var iid = new Guid("6f15aaf2-d208-4e89-9ab4-489535d34f9c");
            nint texture = 0;
            var call = (delegate* unmanaged[Stdcall]<nint,Guid*,nint*,int>)(*(nint**)access)[3];
            Marshal.ThrowExceptionForHR(call(access,&iid,&texture));
            return texture;
        }
        finally { if (access != 0) Marshal.Release(access); Marshal.Release(managed); }
    }

    (int x, int y, int w, int h) ClientCrop(int fw, int fh)
    {
        GetClientRect(hwnd, out var c);
        var origin = new POINT();
        ClientToScreen(hwnd, ref origin);
        RECT border;
        if (display) border = MonitorBounds(monitor);
        else DwmGetWindowAttribute(hwnd, 9, out border, Marshal.SizeOf<RECT>());
        int x = Math.Clamp(origin.X - border.Left, 0, Math.Max(0, fw - 2));
        int y = Math.Clamp(origin.Y - border.Top, 0, Math.Max(0, fh - 2));
        // Fullscreen has no frame; WGC content dimensions are authoritative.
        return (x, y, Math.Max(2, Math.Min(c.Right, fw - x)), Math.Max(2, Math.Min(c.Bottom, fh - y)));
    }

    static unsafe void CopyFit(nint source, int pitch, (int x, int y, int w, int h) c, byte[] output, int w, int h)
    {
        fixed (byte* dst = output)
        {
            byte* src = (byte*)source + c.y * pitch + c.x * 4;
            if (c.w == w && c.h == h)
            {
                for (int y = 0; y < h; y++) Buffer.MemoryCopy(src + y * pitch, dst + y * w * 4, w * 4, w * 4);
                return;
            }
            double scale = Math.Min((double)w / c.w, (double)h / c.h);
            int tw = Math.Max(1, (int)(c.w * scale)), th = Math.Max(1, (int)(c.h * scale));
            int ox = (w - tw) / 2, oy = (h - th) / 2;
            for (int y = 0; y < th; y++)
            {
                uint* row = (uint*)(src + Math.Min(c.h - 1, (int)(y / scale)) * pitch);
                uint* target = (uint*)(dst + ((y + oy) * w + ox) * 4);
                for (int x = 0; x < tw; x++) target[x] = row[Math.Min(c.w - 1, (int)(x / scale))];
            }
        }
    }

    public byte[]? Frame() { lock (gate) return latest; }
    public bool Minimized => IsIconic(hwnd);
    public bool Capturable
    {
        get
        {
            if (!IsWindow(hwnd) || Minimized) return false;
            if (!display) return true;
            GetWindowThreadProcessId(GetForegroundWindow(),out int activePid);
            return activePid == ownerPid;
        }
    }
    public string Source => display ? "focused_display_dxgi" : "window";
    public string WindowId => hwnd.ToString("X");
    public string CurrentWindowId { get { try { return Process.GetProcessById(GetWindowProcess()).MainWindowHandle.ToString("X"); } catch { return "closed"; } } }
    int GetWindowProcess() { GetWindowThreadProcessId(hwnd,out int pid); return pid; }
    static RECT MonitorBounds(nint monitor)
    {
        var info = new MONITORINFO { Size = Marshal.SizeOf<MONITORINFO>() };
        if (!GetMonitorInfo(monitor,ref info)) throw new Exception("The game's display is unavailable.");
        return info.Monitor;
    }
    internal static void SetDpiAwareness() => SetProcessDpiAwarenessContext(new nint(-4));
    public bool CopyFrame(byte[] destination, out double sourceSeconds,bool first = false)
    {
        lock (gate)
        {
            sourceSeconds = sourceTime;
            if (latest == null) return false;
            // Two frames of headroom absorb compositor/encoder wake-up jitter.
            // Sampling only "latest" at 60 Hz otherwise duplicates/skips frames
            // whenever the two clocks cross, even when both sustain 60 FPS.
            if (first && queued.Count < 2) return false;
            if (queued.Count == 0) return true; // Preserve last pixels if minimized.
            var frame = queued.Dequeue();
            sourceSeconds = frame.Time;
            Buffer.BlockCopy(buffers![frame.Slot], 0, destination, 0, latest.Length);
            return true;
        }
    }
    public void Dispose()
    {
        lock (gate) { if (disposed) return; disposed = true; }
        if (pool != null) pool.FrameArrived -= Arrived;
        displayCancel?.Cancel(); displayTask?.Wait(); displayCancel?.Dispose();
        session?.Dispose(); pool?.Dispose(); staging?.Dispose(); if (winrt is IDisposable closeDevice) closeDevice.Dispose(); context.Dispose(); device.Dispose();
    }
    [ComImport, Guid("3628E81B-3CAC-4C60-B7F4-23CE0E0C3356"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IGraphicsCaptureItemInterop
    {
        nint CreateForWindow(nint window, in Guid iid);
        nint CreateForMonitor(nint monitor, in Guid iid);
    }
    [DllImport("user32.dll")] static extern bool IsWindow(nint window);
    [DllImport("d3d11.dll")] static extern int CreateDirect3D11DeviceFromDXGIDevice(nint device, out nint result);
    [DllImport("user32.dll")] static extern bool GetClientRect(nint window, out RECT rect);
    [DllImport("user32.dll")] static extern bool IsIconic(nint window);
    [DllImport("user32.dll")] static extern nint GetForegroundWindow();
    [DllImport("user32.dll")] static extern nint MonitorFromWindow(nint window,uint flags);
    [DllImport("user32.dll")] static extern bool GetMonitorInfo(nint monitor,ref MONITORINFO info);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(nint window,out int pid);
    [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(nint value);
    [DllImport("user32.dll")] static extern bool ClientToScreen(nint window, ref POINT point);
    [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(nint window, int attr, out RECT rect, int size);
    [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] struct MONITORINFO { public int Size; public RECT Monitor, Work; public uint Flags; }
}
