using System.Runtime.InteropServices;

namespace GoobCapture;

static class Chime
{
    // A separate process audio session: game Master mute does not silence a
    // clipping confirmation, and this sound never enters the game's audio taps.
    internal static void Play(string kind, double volume)
    {
        string path = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"..","assets",kind == "error" ? "clip-error.wav" : "clip-saved.wav"));
        if (!File.Exists(path)) return;
        var wave = File.ReadAllBytes(path);
        volume = Math.Clamp(volume,0,1);
        for (int i = 44; i + 1 < wave.Length; i += 2)
        {
            short sample = BitConverter.ToInt16(wave,i);
            BitConverter.TryWriteBytes(wave.AsSpan(i,2),(short)(sample * volume));
        }
        PlaySound(wave,0,0x0004 | 0x0002); // MEMORY | NODEFAULT, synchronous on helper thread.
    }
    [DllImport("winmm.dll",EntryPoint="PlaySoundW",SetLastError=true)]
    static extern bool PlaySound(byte[] data,nint module,uint flags);
}
