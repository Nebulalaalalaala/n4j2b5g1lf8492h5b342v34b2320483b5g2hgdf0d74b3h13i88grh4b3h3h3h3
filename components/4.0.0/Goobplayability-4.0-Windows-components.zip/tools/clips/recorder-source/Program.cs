using System.Diagnostics;
using System.Globalization;
using System.Text.Json;

namespace GoobCapture;

record Config(int Pid, string Session, string Output, string Encoder, int Fps = 60, int Height = 1080,
    int Duration = 45, int Buffer = 90, int Quality = 20, int SampleRate = 48000, string CaptureMode = "auto", string Compression = "balanced");
record Command(string Id, string Kind, double End = 0, double Duration = 0, string Label = "Clip", int Kills = 0, double Volume = .5);

static class Program
{
    internal static readonly JsonSerializerOptions Json = new() { PropertyNameCaseInsensitive = true, PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower };
    [MTAThread]
    static int Main(string[] args)
    {
        if (args.Length == 3 && args[0] == "--chime")
        {
            if (double.TryParse(args[2],System.Globalization.NumberStyles.Float,CultureInfo.InvariantCulture,out var volume)) Chime.Play(args[1],volume);
            return 0;
        }
        if (args.Length != 1) return 2;
        string? session = null;
        try
        {
            var c = JsonSerializer.Deserialize<Config>(File.ReadAllText(args[0]), Json) ?? throw new Exception("Missing recorder settings.");
            WindowCapture.SetDpiAwareness();
            session = Path.GetFullPath(c.Session);
            using var recorder = new Recorder(c);
            recorder.Run();
            return 0;
        }
        catch (Exception e)
        {
            if (session != null) File.WriteAllText(Path.Combine(session, "recorder-error.log"), e.ToString());
            if (session != null) AtomicJson(Path.Combine(session, "status.json"), new { state = "error", message = e.Message });
            return 1;
        }
    }
    internal static void AtomicJson(string path, object data)
    {
        var temp = path + "." + Guid.NewGuid().ToString("N") + ".writing";
        File.WriteAllText(temp, JsonSerializer.Serialize(data, Json));
        // Godot and PowerShell readers can briefly open without FILE_SHARE_DELETE.
        // A status read must never kill the recording or lose a completed clip.
        for (int attempt = 0; attempt < 30; attempt++)
        {
            try { File.Move(temp, path, true); return; }
            catch (IOException) { Thread.Sleep(10); }
            catch (UnauthorizedAccessException) { Thread.Sleep(10); }
        }
        Recorder.TryDelete(temp);
    }
    internal static Process Start(string exe, IEnumerable<string> args, bool input = false)
    {
        var info = new ProcessStartInfo(exe) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardError = true, RedirectStandardInput = input };
        foreach (var a in args) info.ArgumentList.Add(a);
        return Process.Start(info) ?? throw new Exception("The video encoder could not start.");
    }
    internal static string Number(double n) => n.ToString("0.######", CultureInfo.InvariantCulture);
}
