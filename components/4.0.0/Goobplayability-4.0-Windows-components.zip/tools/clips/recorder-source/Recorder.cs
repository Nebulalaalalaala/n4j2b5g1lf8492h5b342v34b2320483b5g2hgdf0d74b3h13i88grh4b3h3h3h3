using System.Diagnostics;
using System.Text.Json;
using System.Collections.Concurrent;

namespace GoobCapture;

sealed class Recorder : IDisposable
{
    readonly Config c;
    readonly WindowCapture capture;
    readonly Stopwatch clock = new();
    readonly string segments;
    readonly ConcurrentQueue<Command> jobs = new();
    readonly HashSet<string> seen = new();
    readonly CancellationTokenSource cancel = new();
    Process? encoder;
    Task? writer;
    Task? export;
    string codec = "libx264";
    string lastError = "";
    long frames;
    long epoch;
    bool stopping;
    readonly object diagnosticGate = new();
    public Recorder(Config config)
    {
        c = config with { Fps = Math.Clamp(config.Fps, 30, 60), Duration = Math.Clamp(config.Duration, 5, 120), Buffer = Math.Clamp(config.Buffer, 15, 180) };
        if (!File.Exists(c.Encoder)) throw new Exception("The bundled video encoder is missing. Repair Clip Studio's recorder files.");
        Directory.CreateDirectory(c.Session);
        Directory.CreateDirectory(c.Output);
        Directory.CreateDirectory(Path.Combine(c.Session, "commands"));
        Directory.CreateDirectory(Path.Combine(c.Session, "results"));
        segments = Path.Combine(c.Session, "segments");
        Directory.CreateDirectory(segments);
        if (new DriveInfo(Path.GetPathRoot(Path.GetFullPath(c.Session))!).AvailableFreeSpace < 1_000_000_000)
            throw new Exception("Clip Studio needs at least 1 GB of free space for its rolling buffer.");
        capture = new WindowCapture(c.Pid,c.Fps,c.CaptureMode);
        capture.Diagnostics = detail =>
        {
            lock (diagnosticGate)
            {
                try
                {
                    string path = Path.Combine(c.Session,"capture-recovery.log");
                    if (File.Exists(path) && new FileInfo(path).Length>65536) File.Move(path,path+".previous",true);
                    File.AppendAllText(path, DateTime.UtcNow.ToString("O")+" "+detail+Environment.NewLine);
                }
                catch { } // Diagnostic IO must never stop a recording.
            }
        };
    }
    public void Run()
    {
        Status("starting", "Preparing game capture");
        codec = ChooseEncoder();
        var wait = Stopwatch.StartNew();
        while (capture.Frame() == null)
        {
            if (capture.TerminalFailure) throw new Exception("Game capture could not recover. Restore GooberDash and restart the replay buffer.", capture.FailureException);
            ReadCommands();
            if (stopping || !ParentAlive()) { Status("stopped","Replay buffer stopped"); return; }
            capture.RefreshSource();
            Status(capture.Capturable ? "starting" : "awaiting_window",capture.Capturable ? "Preparing game capture" : "Return to GooberDash to start capture");
            if (!capture.Capturable) wait.Restart();
            else if (wait.Elapsed.TotalSeconds > 12) throw new Exception("No game frames received. Restore the game window and try again.");
            Thread.Sleep(150);
        }
        if (capture.Frame() == null) throw new Exception("No game frames received. Restore the game window and try again.");
        var args = new List<string> { "-hide_banner", "-loglevel", "warning", "-y", "-filter_threads", "2", "-f", "rawvideo", "-pixel_format", "bgra", "-video_size", $"{capture.Width}x{capture.Height}", "-framerate", c.Fps.ToString(), "-i", "pipe:0", "-an" };
        args.AddRange(new[] { "-vf", $"scale=-2:'min({c.Height},ih)':flags=lanczos", "-pix_fmt", "yuv420p" });
        args.AddRange(VideoEncoding.Arguments(codec,c.Quality,c.Compression,Math.Min(c.Height,capture.Height),c.Fps));
        args.AddRange(new[] { "-bf", "0", "-g", (c.Fps * 2).ToString(), "-keyint_min", (c.Fps * 2).ToString(), "-sc_threshold", "0", "-force_key_frames", "expr:gte(t,n_forced*2)", "-f", "segment", "-segment_format", "matroska", "-segment_time", "2", "-segment_list", Path.Combine(segments, "index.csv"), "-segment_list_type", "csv", "-reset_timestamps", "1", Path.Combine(segments, "%06d.mkv") });
        encoder = Program.Start(c.Encoder, args, true);
        encoder.ErrorDataReceived += (_, e) => { if (e.Data != null) lastError = e.Data; };
        encoder.BeginErrorReadLine();
        clock.Start();
        writer = Task.Run(WriteFrames);
        long nextStatus = 0, nextPrune = 0;
        long nextSourceCheck = 0;
        while (!stopping)
        {
            if (!ParentAlive()) { stopping = true; break; }
            if (encoder.HasExited) throw new Exception("Video encoder stopped: " + lastError);
            if (clock.ElapsedMilliseconds >= nextSourceCheck) { nextSourceCheck = clock.ElapsedMilliseconds+700; capture.RefreshSource(); }
            if (capture.TerminalFailure) throw new Exception("Game capture could not recover. Restore GooberDash and restart the replay buffer.", capture.FailureException);
            if (capture.Closed || !ParentAlive()) stopping = true;
            ReadCommands();
            if (clock.ElapsedMilliseconds >= nextStatus)
            {
                nextStatus = clock.ElapsedMilliseconds + 500;
                string state = !capture.Capturable || Environment.TickCount64 - capture.LastFrameMs > 1500 ? "waiting" : "buffering";
                Status(frames==0 ? "starting" : state, state == "waiting" ? (capture.Capturable && capture.Recoveries>0 ? "Recovering Windows game capture" : "Game window paused or minimized") : "Ready");
            }
            if ((export == null || export.IsCompleted) && jobs.TryPeek(out var next))
            {
                double available = Interlocked.Read(ref frames) / (double)c.Fps;
                if (available >= next.End + 2.3 || stopping)
                {
                    jobs.TryDequeue(out var job);
                    export = Task.Run(() => Export(job!));
                }
            }
            if (clock.ElapsedMilliseconds >= nextPrune && (export == null || export.IsCompleted) && jobs.IsEmpty)
            {
                nextPrune = clock.ElapsedMilliseconds + 3000;
                Prune();
                if (new DriveInfo(Path.GetPathRoot(c.Session)!).AvailableFreeSpace < 300_000_000) throw new Exception("The recorder stopped because disk space is low. Existing clips are safe.");
            }
            Thread.Sleep(40);
        }
        cancel.Cancel();
        writer.Wait(TimeSpan.FromSeconds(5));
        try { encoder.StandardInput.Close(); } catch { }
        if (!encoder.WaitForExit(10000)) encoder.Kill(true);
        export?.Wait();
        while (jobs.TryDequeue(out var job)) Export(job);
        Status("stopped", "Replay buffer stopped");
    }
    bool ParentAlive() { try { return !Process.GetProcessById(c.Pid).HasExited; } catch { return false; } }
    void WriteFrames()
    {
        try
        {
            var stream = encoder!.StandardInput.BaseStream;
            var pixels = new byte[capture.Width * capture.Height * 4];
            while (!cancel.IsCancellationRequested)
            {
                long next = Interlocked.Read(ref frames);
                double due = next * 1000.0 / c.Fps;
                double delay = due - clock.Elapsed.TotalMilliseconds;
                if (delay > 1) { Thread.Sleep((int)Math.Min(10, delay)); continue; }
                if (delay < -5000) throw new Exception("The encoder cannot keep up. Choose 720p or 30 FPS in Clip Studio.");
                if (!capture.CopyFrame(pixels,out double sourceSeconds,next==0)) { Thread.Sleep(1); continue; }
                if (next == 0)
                {
                    // PTS zero represents the compositor's frame time, not the
                    // later CPU readback time. Audio uses the same wall clock.
                    double age = Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency - sourceSeconds;
                    epoch = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - (long)Math.Round(age * 1000);
                    clock.Restart();
                }
                stream.Write(pixels);
                Interlocked.Increment(ref frames);
            }
        }
        catch (Exception e) { lastError = e.Message; stopping = true; Status("error", e.Message); }
    }
    void ReadCommands()
    {
        foreach (var path in Directory.EnumerateFiles(Path.Combine(c.Session, "commands"), "*.json").Order())
        {
            try
            {
                var job = JsonSerializer.Deserialize<Command>(File.ReadAllText(path), Program.Json);
                if (job == null || !seen.Add(job.Id)) continue;
                if (job.Kind == "sound") { _ = Task.Run(() => Chime.Play(job.Label,job.Volume)); continue; }
                if (job.Kind == "stop") { stopping = true; return; }
                if (job.Kind != "save") continue;
                if (jobs.Count >= 4) { Result(job, "error", "The clip queue is full. Try again after the current clips finish."); continue; }
                double now = Interlocked.Read(ref frames) / (double)c.Fps;
                double end = job.End <= 0 ? now : Math.Min(now, job.End);
                double length = Math.Clamp(job.Duration <= 0 ? c.Duration : job.Duration, 1, Math.Min(c.Buffer - 4, 120));
                job = job with { End = end, Duration = Math.Min(length, end), Label = job.Label.Length > 80 ? job.Label[..80] : job.Label };
                if (job.Duration < .25) { Result(job, "error", "The buffer is still warming up. Try again in a moment."); continue; }
                jobs.Enqueue(job);
                Result(job, "saving", "Saving clip");
            }
            catch (IOException) { } // Atomic producer; a locked file is retried next poll.
        }
    }
    void Export(Command job)
    {
        string work = Path.Combine(c.Session, "export-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(work);
        string? partial = null;
        try
        {
            var all = SegmentIndex();
            double wantedStart = Math.Max(0, job.End - job.Duration);
            var chosen = all.Where(s => s.End > wantedStart && s.Start < job.End && File.Exists(s.Path)).ToArray();
            if (chosen.Length == 0) throw new Exception("This part of the replay buffer is no longer available.");
            double start = Math.Max(wantedStart, chosen[0].Start), end = Math.Min(job.End, chosen[^1].End);
            double duration = end - start;
            if (duration < .1) throw new Exception("No complete frames available yet.");
            var list = new List<string>();
            foreach (var s in chosen)
            {
                string copy = Path.Combine(work, Path.GetFileName(s.Path));
                File.Copy(s.Path, copy);
                list.Add("file '" + copy.Replace("\\", "/").Replace("'", "'\\''") + "'");
            }
            string concat = Path.Combine(work, "files.txt");
            File.WriteAllLines(concat, list);
            string wav = Path.Combine(work, "game.wav");
            bool hasAudio = AudioTrack.Build(c.Session, wav, epoch + start * 1000, duration, c.SampleRate);
            string slug = new string(job.Label.Where(x => char.IsLetterOrDigit(x) || x == ' ' || x == '-').ToArray()).Trim().Replace(' ', '-');
            if (slug.Length == 0) slug = "Clip";
            string path = Path.Combine(c.Output, $"Goob-{DateTime.Now:yyyyMMdd-HHmmss}-{slug}-{job.Id[^Math.Min(job.Id.Length, 5)..]}.mp4");
            partial = path + ".partial.mp4";
            var args = new List<string> { "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", concat };
            if (hasAudio) args.AddRange(new[] { "-i", wav });
            args.AddRange(new[] { "-t", Program.Number(duration), "-map", "0:v:0", "-vf", $"trim=start={Program.Number(start - chosen[0].Start)}:duration={Program.Number(duration)},setpts=PTS-STARTPTS" });
            args.AddRange(VideoEncoding.Arguments(codec,c.Quality,c.Compression,Math.Min(c.Height,capture.Height),c.Fps));
            if (hasAudio) args.AddRange(new[] { "-map", "1:a:0", "-c:a", "aac", "-b:a", "192k" });
            else args.Add("-an");
            args.AddRange(new[] { "-r", c.Fps.ToString(), "-pix_fmt", "yuv420p", "-movflags", "+faststart", partial });
            using var process = Program.Start(c.Encoder, args);
            var errorTask = process.StandardError.ReadToEndAsync();
            if (!process.WaitForExit(180000)) { process.Kill(true); throw new Exception("The clip export took too long. Lower recording quality and try again."); }
            string error = errorTask.GetAwaiter().GetResult();
            if (process.ExitCode != 0) throw new Exception("Clip export failed: " + error);
            File.Move(partial, path);
            Program.AtomicJson(Path.ChangeExtension(path, ".json"), new { version = 1, label = job.Label, kills = job.Kills, duration, fps = c.Fps, width = OutputWidth, height = OutputHeight, codec, game_audio = hasAudio, created = DateTimeOffset.UtcNow.ToUnixTimeSeconds() });
            // Thumbnails are optional: a failed thumbnail never invalidates a saved clip.
            using var thumb = Program.Start(c.Encoder, new[] { "-hide_banner", "-loglevel", "error", "-y", "-ss", Program.Number(duration * .6), "-i", path, "-frames:v", "1", "-vf", "scale=320:-2", Path.ChangeExtension(path, ".jpg") });
            var thumbError = thumb.StandardError.ReadToEndAsync();
            if (!thumb.WaitForExit(10000)) thumb.Kill(true);
            Result(job, "saved", "Clip saved", path, duration);
        }
        catch (Exception e) { Result(job, "error", e.Message); if (partial != null) TryDelete(partial); }
        finally { try { Directory.Delete(work, true); } catch { } }
    }
    record Segment(string Path, double Start, double End);
    Segment[] SegmentIndex()
    {
        string path = Path.Combine(segments, "index.csv");
        if (!File.Exists(path)) return Array.Empty<Segment>();
        using var f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using var reader = new StreamReader(f);
        var output = new List<Segment>();
        while (reader.ReadLine() is { } line)
        {
            var fields = line.Split(',');
            if (fields.Length != 3 || !double.TryParse(fields[1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double start) || !double.TryParse(fields[2], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double end)) continue;
            output.Add(new Segment(Path.Combine(segments, Path.GetFileName(fields[0].Trim('"'))), start, end));
        }
        return output.ToArray();
    }
    void Prune()
    {
        double cutoff = Interlocked.Read(ref frames) / (double)c.Fps - c.Buffer - 6;
        foreach (var s in SegmentIndex()) if (s.End < cutoff) TryDelete(s.Path);
        foreach (var file in Directory.EnumerateFiles(c.Session, "audio-*.gca"))
            if (File.GetLastWriteTimeUtc(file) < DateTime.UtcNow.AddSeconds(-c.Buffer - 15)) TryDelete(file);
    }
    internal static void TryDelete(string path) { try { File.Delete(path); } catch { } }
    void Result(Command job, string state, string message, string path = "", double duration = 0) =>
        Program.AtomicJson(Path.Combine(c.Session, "results", job.Id + ".json"), new { id = job.Id, state, message, path, duration, label = job.Label, kills = job.Kills });
    int OutputHeight => Math.Min(c.Height,capture.Height);
    int OutputWidth => capture.Height == 0 ? 0 : (int)(capture.Width * (double)OutputHeight / capture.Height) & ~1;
    void Status(string state, string message) => Program.AtomicJson(Path.Combine(c.Session, "status.json"), new { state, message, recorder_build = "20261104f", capture_recoveries = capture.Recoveries, capture_device_resets = capture.DeviceResets, last_recovery = capture.LastRecovery, seconds = Math.Min(c.Buffer, Interlocked.Read(ref frames) / (double)c.Fps), elapsed = Interlocked.Read(ref frames) / (double)c.Fps, epoch, codec, fps = c.Fps, width = OutputWidth, height = OutputHeight, capture_frames = capture.ReceivedFrames, capture_acquisitions = capture.AcquisitionAttempts, frame_age_ms = Environment.TickCount64 - capture.LastFrameMs, source = capture.Source, minimized = capture.Minimized, target_window = capture.WindowId, current_window = capture.CurrentWindowId, queue = jobs.Count + (export != null && !export.IsCompleted ? 1 : 0) });
    string ChooseEncoder()
    {
        foreach (string candidate in new[] { "h264_nvenc", "h264_qsv", "h264_amf" })
        {
            using var test = Program.Start(c.Encoder, new[] { "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=black:s=320x180:r=30", "-t", "0.1", "-c:v", candidate, "-f", "null", "-" });
            var error = test.StandardError.ReadToEndAsync();
            if (!test.WaitForExit(5000)) test.Kill(true);
            else if (test.ExitCode == 0) return candidate;
        }
        return "libx264";
    }
    public void Dispose()
    {
        cancel.Cancel();
        capture.Dispose();
        if (encoder is { HasExited: false }) { try { encoder.StandardInput.Close(); if (!encoder.WaitForExit(3000)) encoder.Kill(true); } catch { } }
        encoder?.Dispose(); cancel.Dispose();
    }
}
