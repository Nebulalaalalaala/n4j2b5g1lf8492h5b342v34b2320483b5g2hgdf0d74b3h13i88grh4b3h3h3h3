namespace GoobCapture;

// Shared by the rolling buffer and final export. Never changes frame cadence,
// capture source or audio timing; the user can restore the previous detail mode.
static class VideoEncoding
{
    internal static string[] Arguments(string codec, int requestedQuality, string profile, int height, int fps)
    {
        profile = profile is "compact" or "detail" ? profile : "balanced";
        int quality = Math.Clamp(requestedQuality,16,32);
        if (profile != "detail") quality = Math.Max(quality,profile=="compact" ? 27 : 24);
        var args = codec switch
        {
            "h264_nvenc" => new[] { "-c:v", codec, "-preset", "p4", "-rc", "vbr", "-cq", quality.ToString(), "-b:v", "0" },
            "h264_qsv" => new[] { "-c:v", codec, "-preset", "veryfast", "-global_quality", quality.ToString() },
            "h264_amf" => new[] { "-c:v", codec, "-quality", "balanced", "-rc", "cqp", "-qp_i", quality.ToString(), "-qp_p", quality.ToString() },
            _ => new[] { "-c:v", "libx264", "-preset", "veryfast", "-crf", quality.ToString(), "-threads", "2" }
        };
        if (profile=="detail") return args;
        int cap = (int)Math.Clamp(8_000_000*Math.Pow(Math.Clamp(height,360,1440)/1080.0,2)*(fps>=60 ? 1 : .65)*(profile=="compact" ? .5 : 1),1_200_000,16_000_000);
        // ICQ/CQP don't provide a bitrate ceiling. Use the encoders' native
        // VBR modes for the bounded profiles, leaving detail mode unchanged.
        if (codec=="h264_qsv") args = new[] { "-c:v",codec,"-preset","veryfast","-b:v",(cap*3/4).ToString() };
        if (codec=="h264_amf") args = new[] { "-c:v",codec,"-quality","balanced","-rc","vbr_peak","-b:v",(cap*3/4).ToString() };
        return args.Concat(new[] { "-maxrate",cap.ToString(),"-bufsize",(cap*2).ToString() }).ToArray();
    }
}
