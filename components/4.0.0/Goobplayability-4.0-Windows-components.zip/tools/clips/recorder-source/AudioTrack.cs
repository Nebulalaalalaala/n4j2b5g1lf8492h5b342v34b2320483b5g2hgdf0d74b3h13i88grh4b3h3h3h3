namespace GoobCapture;

static class AudioTrack
{
    // Each game-side block: UInt64 UTC microseconds, UInt32 stereo frame count,
    // then interleaved IEEE float32 samples. No endpoint/desktop/microphone audio.
    internal static bool Build(string session, string path, double startMs, double seconds, int rate)
    {
        int frames = (int)Math.Ceiling(seconds * rate);
        var mix = new float[frames * 2];
        bool found = false;
        foreach (var file in Directory.EnumerateFiles(session, "audio-*.gca"))
        {
            using var stream = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var reader = new BinaryReader(stream);
            while (stream.Length - stream.Position >= 12)
            {
                double stamp = reader.ReadUInt64() / 1000.0;
                int count = reader.ReadInt32();
                if (count < 0 || count > rate * 4 || stream.Length - stream.Position < count * 8L) break;
                int offset = (int)Math.Round((stamp - startMs) * rate / 1000);
                if (offset + count <= 0 || offset >= frames) { stream.Position += count * 8L; continue; }
                found = true;
                for (int i = 0; i < count; i++)
                {
                    float left = reader.ReadSingle(), right = reader.ReadSingle();
                    int at = offset + i;
                    if (at < 0 || at >= frames) continue;
                    if (float.IsFinite(left)) mix[at * 2] += left;
                    if (float.IsFinite(right)) mix[at * 2 + 1] += right;
                }
            }
        }
        if (!found) return false;
        using var output = new BinaryWriter(File.Create(path));
        output.Write("RIFF"u8); output.Write(36 + frames * 4); output.Write("WAVEfmt "u8);
        output.Write(16); output.Write((short)1); output.Write((short)2); output.Write(rate);
        output.Write(rate * 4); output.Write((short)4); output.Write((short)16);
        output.Write("data"u8); output.Write(frames * 4);
        foreach (float value in mix) output.Write((short)(Math.Clamp(value, -1f, 1f) * 32767));
        return true;
    }
}
