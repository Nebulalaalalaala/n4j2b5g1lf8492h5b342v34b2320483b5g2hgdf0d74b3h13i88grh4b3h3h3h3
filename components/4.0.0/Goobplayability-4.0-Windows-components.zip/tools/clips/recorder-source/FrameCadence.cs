namespace GoobCapture;

// Absolute sampling deadlines avoid cadence drift and busy polling a fast game.
// Large stalls restart from now rather than acquiring a burst of obsolete frames.
sealed class FrameCadence
{
    readonly double period;
    double next;
    public FrameCadence(int fps) => period = 1.0/Math.Clamp(fps,1,240);
    public double WaitSeconds(double now) => Math.Clamp(next-now,0.0,0.04);
    public void Accept(double now) => next = now-next>.5 ? now+period : next+period;
}
