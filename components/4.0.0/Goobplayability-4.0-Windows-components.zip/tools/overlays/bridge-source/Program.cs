using System.Diagnostics;
using System.Collections.Concurrent;
using System.Runtime.InteropServices;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using Windows.Devices.Enumeration;
using Windows.Graphics.Imaging;
using Windows.Media.Capture;
using Windows.Media.Capture.Frames;
using Windows.Media.Control;
using Windows.Media.MediaProperties;
using Windows.Storage;
using Windows.Storage.Streams;

record Settings(int Pid,string Session,string Token);
record TrackInfo(string title,string artist,string album,string artwork,string revision);
record AcceptedSeek(double position,long at,bool playing,long stamp,string track);
sealed class Bridge : IAsyncDisposable
{
    readonly Settings settings;
    readonly CancellationTokenSource cancel=new();
    readonly SemaphoreSlim writes=new(1,1);
    readonly ConcurrentDictionary<string,GlobalSystemMediaTransportControlsSession> sessions=new();
    readonly ConcurrentDictionary<string,TrackInfo> metadata=new();
    readonly ConcurrentDictionary<string,string> deliveredArt=new();
    readonly ConcurrentDictionary<string,AcceptedSeek> seeks=new();
    readonly ConcurrentDictionary<string,CameraFeed> cameras=new();
    readonly TcpListener listener=new(IPAddress.Loopback,0);
    TcpClient? connection;
    NetworkStream? stream;
    GlobalSystemMediaTransportControlsSessionManager? manager;
    List<object> devices=new();
    string mediaError="";
    string cameraError="";
    
    public Bridge(Settings s)=>settings=s;
    bool OwnerAlive(){ try { return !Process.GetProcessById(settings.Pid).HasExited; } catch{return false;} }
    public async Task Run()
    {
        Directory.CreateDirectory(settings.Session);
        try { manager=await GlobalSystemMediaTransportControlsSessionManager.RequestAsync(); }
        catch(Exception e){mediaError="Windows media sessions unavailable: "+e.Message;}
        listener.Start(1);
        Atomic(Path.Combine(settings.Session,"status.json"),new{version=1,port=((IPEndPoint)listener.LocalEndpoint).Port,ready=true});
        using var timeout=CancellationTokenSource.CreateLinkedTokenSource(cancel.Token);
        timeout.CancelAfter(TimeSpan.FromSeconds(20));
        connection=await listener.AcceptTcpClientAsync(timeout.Token);
        connection.NoDelay=true;
        stream=connection.GetStream();
        var authentication=await ReadPacket(timeout.Token);
        if(authentication.Length<2 || authentication[0]!=3)throw new Exception("Invalid local handshake");
        using(var doc=JsonDocument.Parse(authentication.AsMemory(1)))
            if(doc.RootElement.GetProperty("token").GetString()!=settings.Token)throw new Exception("Invalid local token");
        await EnumerateDevices();
        var commands=ReadCommands();
        while(!cancel.IsCancellationRequested && OwnerAlive() && !commands.IsCompleted)
        {
            await RefreshSessions();
            await SendState();
            await Task.Delay(750,cancel.Token);
        }
        cancel.Cancel();
        try {await commands;}catch(OperationCanceledException){}
    }
    async Task<byte[]> ReadPacket(CancellationToken token)
    {
        var header=new byte[4]; await stream!.ReadExactlyAsync(header,token);
        int size=BitConverter.ToInt32(header); if(size<1 || size>32768)throw new Exception("Invalid local command size");
        var data=new byte[size]; await stream.ReadExactlyAsync(data,token); return data;
    }
    async Task ReadCommands()
    {
        try{
            while(!cancel.IsCancellationRequested){
                var packet=await ReadPacket(cancel.Token); if(packet[0]!=3)continue;
                using var json=JsonDocument.Parse(packet.AsMemory(1)); var command=json.RootElement;
                string action=Get(command,"action");
                if(action=="stop"){cancel.Cancel();return;}
                if(action=="devices"){await EnumerateDevices();await SendState();continue;}
                if(action=="camera_start"){
                    string id=Get(command,"device");
                    if(!devices.Any(d=>JsonSerializer.SerializeToElement(d).GetProperty("id").GetString()==id)){cameraError="Camera is not connected";await SendState();continue;}
                    await StopCamera(id);
                    var feed=new CameraFeed(id,Number(command,"width",640),Number(command,"height",360),Number(command,"fps",15),this);
                    try{await feed.Start(); cameras[id]=feed; cameraError="";}catch(Exception e){await feed.DisposeAsync();cameraError="Camera could not start: "+e.Message;}
                    await SendState();continue;
                }
                if(action=="camera_stop"){await StopCamera(Get(command,"device"));await SendState();continue;}
                if(action=="file_metadata"){
                    await FileMetadata(Get(command,"path"));continue;
                }
                string key=Get(command,"session");
                if(!sessions.TryGetValue(key,out var session))continue;
                var controls=session.GetPlaybackInfo().Controls;
                try{
                    if(action=="toggle" && (controls.IsPlayEnabled || controls.IsPauseEnabled))await session.TryTogglePlayPauseAsync();
                    else if(action=="next" && controls.IsNextEnabled)await session.TrySkipNextAsync();
                    else if(action=="previous" && controls.IsPreviousEnabled)await session.TrySkipPreviousAsync();
                    else if(action=="seek" && controls.IsPlaybackPositionEnabled){
                        double seconds=command.TryGetProperty("seconds",out var v)?v.GetDouble():0;
                        var timeline=session.GetTimelineProperties();
                        double start=timeline.StartTime.TotalSeconds;
                        double end=Math.Max(timeline.EndTime.TotalSeconds,timeline.MaxSeekTime.TotalSeconds);
                        double requested=end>start?Math.Clamp(seconds,start,end):Math.Max(0,seconds);
                        if(await session.TryChangePlaybackPositionAsync((long)(requested*TimeSpan.TicksPerSecond))){
                            var observed=session.GetTimelineProperties();var info=metadata.GetValueOrDefault(key);
                            seeks[key]=new AcceptedSeek(requested,Environment.TickCount64,session.GetPlaybackInfo().PlaybackStatus==GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing,observed.LastUpdatedTime.Ticks,info==null?"":info.title+"\n"+info.artist);
                        }
                    }
                }catch{mediaError="This player did not accept the control request";}
                await SendState();
            }
        }catch(EndOfStreamException){cancel.Cancel();}
        catch(IOException){cancel.Cancel();}
        catch(OperationCanceledException){}
    }
    async Task EnumerateDevices()
    {
        try{devices=(await DeviceInformation.FindAllAsync(DeviceClass.VideoCapture)).Select(d=>(object)new{id=d.Id,name=d.Name}).ToList();cameraError="";}
        catch(Exception e){cameraError="Camera discovery unavailable: "+e.Message;}
    }
    async Task RefreshSessions()
    {
        if(manager==null)return;
        try{
            var live=new HashSet<string>();
            foreach(var session in manager.GetSessions().Take(16)){
                if(session.GetPlaybackInfo().PlaybackStatus==GlobalSystemMediaTransportControlsSessionPlaybackStatus.Closed)continue;
                string key=session.SourceAppUserModelId+"::"+session.GetHashCode().ToString("x");live.Add(key);
                if(!sessions.ContainsKey(key)){
                    sessions[key]=session;
                    session.MediaPropertiesChanged+=(_,_)=>metadata.TryRemove(key,out var _);
                }
                bool missing=!metadata.ContainsKey(key);
                if(missing){
                    var media=await session.TryGetMediaPropertiesAsync();
                    string art="";
                    try{if(media.Thumbnail!=null){using var input=await media.Thumbnail.OpenReadAsync();art=await PngArtwork(input);}}catch{}
                    metadata[key]=new TrackInfo(media.Title??"",media.Artist??"",media.AlbumTitle??"",art,Guid.NewGuid().ToString("N"));
                }
            }
            foreach(var key in sessions.Keys.Where(k=>!live.Contains(k)).ToArray()){sessions.TryRemove(key,out var _);metadata.TryRemove(key,out var _);deliveredArt.TryRemove(key,out var _);seeks.TryRemove(key,out var _);}
            mediaError="";
        }catch(Exception e){mediaError="Media information unavailable: "+e.Message;}
    }
    async Task SendState()
    {
        var rows=new List<object>();string current="";
        var active=manager?.GetCurrentSession();
        foreach(var (key,session) in sessions.ToArray()){
            try{
                var playback=session.GetPlaybackInfo();var controls=playback.Controls;var timeline=session.GetTimelineProperties();
                var track=metadata.GetValueOrDefault(key,new TrackInfo("","","","",""));
                bool artChanged=deliveredArt.GetValueOrDefault(key)!=track.revision;
                var info=new{track.title,track.artist,track.album,artwork=artChanged?track.artwork:"",track.revision};
                deliveredArt[key]=track.revision;
                bool playing=playback.PlaybackStatus==GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing;
                double position=timeline.Position.TotalSeconds;
                if(playing){double elapsed=(DateTimeOffset.UtcNow-timeline.LastUpdatedTime).TotalSeconds;if(elapsed>=0 && elapsed<7200)position+=elapsed;}
                double end=Math.Max(timeline.EndTime.TotalSeconds,timeline.MaxSeekTime.TotalSeconds);
                if(seeks.TryGetValue(key,out var seek)){
                    if(timeline.LastUpdatedTime.Ticks==seek.stamp && track.title+"\n"+track.artist==seek.track){
                        position=seek.position+(seek.playing?Math.Max(0,Environment.TickCount64-seek.at)/1000.0:0);
                        seeks[key]=seek with{position=position,at=Environment.TickCount64,playing=playing};
                    }else seeks.TryRemove(key,out var _);
                }
                if(end>timeline.StartTime.TotalSeconds)position=Math.Clamp(position,timeline.StartTime.TotalSeconds,end);
                if(active?.SourceAppUserModelId==session.SourceAppUserModelId)current=key;
                rows.Add(new{id=key,app=session.SourceAppUserModelId,info,playing,position,start=timeline.StartTime.TotalSeconds,duration=end,controls=new{toggle=controls.IsPlayEnabled||controls.IsPauseEnabled,next=controls.IsNextEnabled,previous=controls.IsPreviousEnabled,seek=controls.IsPlaybackPositionEnabled,volume=false}});
            }catch{}
        }
        await SendJson(new{kind="state",sessions=rows,current,media_error=mediaError,cameras=devices,camera_error=cameraError,active_cameras=cameras.Keys.ToArray()});

    }
    async Task FileMetadata(string path)
    {
        if(!Path.IsPathFullyQualified(path) || !new[]{".mp3",".wav",".ogg"}.Contains(Path.GetExtension(path).ToLowerInvariant()))return;
        try{
            var file=await StorageFile.GetFileFromPathAsync(path);var data=await file.Properties.GetMusicPropertiesAsync();
            string art="";
            try{using var thumbnail=await file.GetThumbnailAsync(Windows.Storage.FileProperties.ThumbnailMode.MusicView,256);if(thumbnail!=null)art=await PngArtwork(thumbnail);}catch{}
            await SendJson(new{kind="file",path,title=data.Title,artist=data.Artist,album=data.Album,duration=data.Duration.TotalSeconds,artwork=art,revision=path});
        }catch{await SendJson(new{kind="file",path,title="",artist="",album="",duration=0});}
    }
    static async Task<string> PngArtwork(IRandomAccessStream input){
        if(input.Size==0 || input.Size>2097152)return "";
        var decoder=await BitmapDecoder.CreateAsync(input);
        using var bitmap=await decoder.GetSoftwareBitmapAsync(BitmapPixelFormat.Bgra8,BitmapAlphaMode.Premultiplied);
        using var target=new InMemoryRandomAccessStream();
        var encoder=await BitmapEncoder.CreateAsync(BitmapEncoder.PngEncoderId,target);
        encoder.SetSoftwareBitmap(bitmap);
        double scale=Math.Min(1,256.0/Math.Max(bitmap.PixelWidth,bitmap.PixelHeight));
        encoder.BitmapTransform.ScaledWidth=(uint)Math.Max(1,bitmap.PixelWidth*scale);
        encoder.BitmapTransform.ScaledHeight=(uint)Math.Max(1,bitmap.PixelHeight*scale);
        await encoder.FlushAsync();
        if(target.Size>262144)return "";
        using var reader=new DataReader(target.GetInputStreamAt(0));await reader.LoadAsync((uint)target.Size);
        var bytes=new byte[target.Size];reader.ReadBytes(bytes);return Convert.ToBase64String(bytes);
    }
    public async Task CameraFailed(string message){cameraError=message;await SendState();}
    async Task StopCamera(string id){if(cameras.TryRemove(id,out var feed))await feed.DisposeAsync();}
    public async Task SendFrame(string id,long sequence,int width,int height,byte[] jpeg)
    {
        using var payload=new MemoryStream();using(var writer=new BinaryWriter(payload,Encoding.UTF8,true)){
            var key=Encoding.UTF8.GetBytes(id);writer.Write((byte)1);writer.Write((ushort)key.Length);writer.Write(key);writer.Write(sequence);writer.Write(width);writer.Write(height);writer.Write(jpeg);
        }
        await Send(payload.ToArray());
    }
    async Task SendJson(object value){var json=JsonSerializer.SerializeToUtf8Bytes(value);var data=new byte[json.Length+1];data[0]=2;json.CopyTo(data,1);await Send(data);}
    async Task Send(byte[] data){
        if(stream==null || data.Length>4194304)return;
        await writes.WaitAsync(cancel.Token);
        try{await stream.WriteAsync(BitConverter.GetBytes(data.Length),cancel.Token);await stream.WriteAsync(data,cancel.Token);}finally{writes.Release();}
    }
    static string Get(JsonElement e,string key)=>e.TryGetProperty(key,out var v)&&v.ValueKind==JsonValueKind.String?v.GetString()??"":"";
    static int Number(JsonElement e,string key,int fallback)=>e.TryGetProperty(key,out var v)&&v.ValueKind==JsonValueKind.Number&&v.TryGetDouble(out var n)&&double.IsFinite(n)?(int)Math.Clamp(n,int.MinValue,int.MaxValue):fallback;
    public static void Atomic(string path,object value){string temp=path+".tmp";File.WriteAllText(temp,JsonSerializer.Serialize(value));File.Move(temp,path,true);}
    public async ValueTask DisposeAsync(){cancel.Cancel();foreach(var feed in cameras.Values)await feed.DisposeAsync();stream?.Dispose();connection?.Dispose();listener.Stop();writes.Dispose();cancel.Dispose();}
}
sealed class CameraFeed : IAsyncDisposable
{
    readonly string id;readonly int width,height,fps;readonly Bridge bridge;
    MediaCapture? capture;MediaFrameReader? reader;StaDispatcher? dispatcher;int busy;long sequence;long next;
    public CameraFeed(string id,int w,int h,int f,Bridge b){this.id=id;width=Math.Clamp(w,160,1920);height=Math.Clamp(h,120,1080);fps=Math.Clamp(f,5,30);bridge=b;}
    public async Task Start(){
        dispatcher=new StaDispatcher();
        await dispatcher.Invoke(Initialize);
    }
    async Task Initialize(){
        capture=new MediaCapture();
        capture.Failed+=(sender,e)=>{_ = bridge.CameraFailed("Camera disconnected or access lost: "+e.Message);};
        await capture.InitializeAsync(new MediaCaptureInitializationSettings{VideoDeviceId=id,StreamingCaptureMode=StreamingCaptureMode.Video,MemoryPreference=MediaCaptureMemoryPreference.Cpu,SharingMode=MediaCaptureSharingMode.ExclusiveControl});
        var source=capture.FrameSources.Values.FirstOrDefault(s=>s.Info.SourceKind==MediaFrameSourceKind.Color)??throw new Exception("No colour video stream");
        var format=source.SupportedFormats.OrderBy(f=>Math.Abs((long)f.VideoFormat.Width-width)+Math.Abs((long)f.VideoFormat.Height-height)+Math.Abs((double)f.FrameRate.Numerator/Math.Max(1,f.FrameRate.Denominator)-fps)*20).First();
        try{await source.SetFormatAsync(format);}catch{}
        reader=await capture.CreateFrameReaderAsync(source,MediaEncodingSubtypes.Bgra8);
        reader.AcquisitionMode=MediaFrameReaderAcquisitionMode.Realtime;
        reader.FrameArrived+=Frame;
        var result=await reader.StartAsync();if(result!=MediaFrameReaderStartStatus.Success)throw new Exception(result.ToString());
    }
    async void Frame(MediaFrameReader sender,MediaFrameArrivedEventArgs args){
        if(Environment.TickCount64<next || Interlocked.Exchange(ref busy,1)!=0)return;
        try{
            using var frame=sender.TryAcquireLatestFrame();var original=frame?.VideoMediaFrame?.SoftwareBitmap;if(original==null)return;
            next=Environment.TickCount64+1000/fps;
            using var bitmap=SoftwareBitmap.Convert(original,BitmapPixelFormat.Bgra8,BitmapAlphaMode.Ignore);
            using var memory=new InMemoryRandomAccessStream();
            var encoder=await BitmapEncoder.CreateAsync(BitmapEncoder.PngEncoderId,memory);encoder.SetSoftwareBitmap(bitmap);await encoder.FlushAsync();
            if(memory.Size>2097152){await bridge.CameraFailed("Camera frames are too large. Select a smaller capture format.");return;}
            using var data=new DataReader(memory.GetInputStreamAt(0));await data.LoadAsync((uint)memory.Size);var bytes=new byte[memory.Size];data.ReadBytes(bytes);
            await bridge.SendFrame(id,Interlocked.Increment(ref sequence),bitmap.PixelWidth,bitmap.PixelHeight,bytes);
        }catch{}finally{Interlocked.Exchange(ref busy,0);}
    }
    public async ValueTask DisposeAsync(){
        if(dispatcher!=null){
            try{await dispatcher.Invoke(async()=>{if(reader!=null){reader.FrameArrived-=Frame;try{await reader.StopAsync();}catch{}reader.Dispose();}capture?.Dispose();});}finally{dispatcher.Dispose();dispatcher=null;}
        }
    }
}
sealed class StaDispatcher : SynchronizationContext, IDisposable
{
    readonly ConcurrentQueue<Action> work=new();
    readonly Thread thread;
    readonly TaskCompletionSource<uint> ready=new(TaskCreationOptions.RunContinuationsAsynchronously);
    uint id;
    const uint Wake=0x8001;
    [StructLayout(LayoutKind.Sequential)] struct Message {public IntPtr hwnd;public uint message;public UIntPtr wParam;public IntPtr lParam;public uint time;public int x,y;public uint privateData;}
    [StructLayout(LayoutKind.Sequential)] struct Options {public uint size,type,apartment;}
    [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] static extern bool PeekMessage(out Message msg,IntPtr hwnd,uint min,uint max,uint remove);
    [DllImport("user32.dll")] static extern int GetMessage(out Message msg,IntPtr hwnd,uint min,uint max);
    [DllImport("user32.dll")] static extern bool TranslateMessage(ref Message msg);
    [DllImport("user32.dll")] static extern IntPtr DispatchMessage(ref Message msg);
    [DllImport("user32.dll")] static extern bool PostThreadMessage(uint id,uint message,UIntPtr wParam,IntPtr lParam);
    [DllImport("CoreMessaging.dll")] static extern int CreateDispatcherQueueController(Options options,out IntPtr controller);
    public StaDispatcher(){
        thread=new Thread(Loop){IsBackground=true,Name="Goob camera STA"};
        thread.SetApartmentState(ApartmentState.STA);thread.Start();
    }
    void Loop(){
        IntPtr queue=IntPtr.Zero;
        try{
            id=GetCurrentThreadId();PeekMessage(out var _,IntPtr.Zero,0,0,0);
            Marshal.ThrowExceptionForHR(CreateDispatcherQueueController(new Options{size=(uint)Marshal.SizeOf<Options>(),type=2,apartment=2},out queue));
            SetSynchronizationContext(this);ready.SetResult(id);
            while(GetMessage(out var msg,IntPtr.Zero,0,0)>0){
                if(msg.message==Wake){while(work.TryDequeue(out var action))action();}
                else{TranslateMessage(ref msg);DispatchMessage(ref msg);}
            }
        }catch(Exception e){ready.TrySetException(e);}
        finally{if(queue!=IntPtr.Zero)Marshal.Release(queue);}
    }
    public override void Post(SendOrPostCallback action,object? state){work.Enqueue(()=>action(state));PostThreadMessage(id,Wake,UIntPtr.Zero,IntPtr.Zero);}
    public async Task Invoke(Func<Task> action){
        await ready.Task;
        var result=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        Post(async _=>{try{await action();result.SetResult();}catch(Exception e){result.SetException(e);}},null);
        await result.Task;
    }
    public void Dispose(){if(id!=0)PostThreadMessage(id,0x12,UIntPtr.Zero,IntPtr.Zero);if(thread.IsAlive)thread.Join(2000);}
}
static class Program
{
    [MTAThread] static async Task<int> Main(string[] args){
        if(args.Length!=1)return 2;Settings? settings=null;
        try{
            settings=JsonSerializer.Deserialize<Settings>(File.ReadAllText(args[0]),new JsonSerializerOptions{PropertyNameCaseInsensitive=true});
            if(settings==null || settings.Token.Length<24)return 2;
            await using var bridge=new Bridge(settings);await bridge.Run();return 0;
        }catch(OperationCanceledException){return 0;}
        catch(Exception e){if(settings!=null)try{Bridge.Atomic(Path.Combine(settings.Session,"status.json"),new{ready=false,error=e.Message});}catch{}return 1;}
    }
}
